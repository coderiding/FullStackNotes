//
//  SystemInfoView.h
//  iOS_2D_RecordPath
//
//  Created by PC on 15/8/4.
//  Copyright (c) 2015年 FENGSHENG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SystemInfoView : UIView

- (void)startUpdateSystemInfo;

- (void)stopUpdateSystemInfo;

@end
