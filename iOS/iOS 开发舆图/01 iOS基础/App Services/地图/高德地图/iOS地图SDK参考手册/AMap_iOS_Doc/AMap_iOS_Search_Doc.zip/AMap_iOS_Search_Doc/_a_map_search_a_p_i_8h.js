var _a_map_search_a_p_i_8h =
[
    [ "AMapSearchAPI", "interface_a_map_search_a_p_i.html", "interface_a_map_search_a_p_i" ],
    [ "<AMapSearchDelegate>", "protocol_a_map_search_delegate-p.html", "protocol_a_map_search_delegate-p" ],
    [ "AMapSearchLanguageEn", "_a_map_search_a_p_i_8h.html#a5f4260b2391777ff6ce8e27d8eeb3272", null ],
    [ "AMapSearchLanguageZhCN", "_a_map_search_a_p_i_8h.html#a0ca99f6445b4db1c6bba61419792491c", null ]
];