var interface_a_map_road_traffic_search_base_request =
[
    [ "level", "interface_a_map_road_traffic_search_base_request.html#aa72b8a1c95ee6ac2c397e76873f17daa", null ],
    [ "requireExtension", "interface_a_map_road_traffic_search_base_request.html#aa3c0f20efd028de737461deb1f2cc65d", null ]
];