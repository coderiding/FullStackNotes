var interface_m_a_polygon =
[
    [ "setPolygonWithCoordinates:count:", "interface_m_a_polygon.html#a499586fdb35a81837bbd6f8758e50db0", null ],
    [ "setPolygonWithPoints:count:", "interface_m_a_polygon.html#afe2295d344b06c22b233c39078f0fa31", null ],
    [ "hollowShapes", "interface_m_a_polygon.html#a9edd7c4812a342bd0bbf99f8c7fb08e9", null ]
];