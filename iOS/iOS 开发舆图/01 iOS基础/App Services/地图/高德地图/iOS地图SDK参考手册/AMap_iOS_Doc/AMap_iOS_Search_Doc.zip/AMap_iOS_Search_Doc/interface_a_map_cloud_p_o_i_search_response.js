var interface_a_map_cloud_p_o_i_search_response =
[
    [ "count", "interface_a_map_cloud_p_o_i_search_response.html#a519c3c425294fd274f70d75dfa54847b", null ],
    [ "POIs", "interface_a_map_cloud_p_o_i_search_response.html#a93f5641cb720f4499cb8505c9faeb2ad", null ]
];