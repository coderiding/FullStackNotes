var interface_a_map_p_o_i_keywords_search_request =
[
    [ "city", "interface_a_map_p_o_i_keywords_search_request.html#ad4554e9820aedd5d2489aed675e26f0e", null ],
    [ "cityLimit", "interface_a_map_p_o_i_keywords_search_request.html#a2a81997220842a23fc7b0368f2afeb62", null ],
    [ "keywords", "interface_a_map_p_o_i_keywords_search_request.html#aa44ee0479a197b982b110afd74eda536", null ],
    [ "location", "interface_a_map_p_o_i_keywords_search_request.html#ac42948a71265196e76618b0b92109d90", null ]
];