var interface_m_a_heat_map_vector_node =
[
    [ "coordinate", "interface_m_a_heat_map_vector_node.html#ae69ac33c40402c00380616844767a8d1", null ],
    [ "weight", "interface_m_a_heat_map_vector_node.html#aaef98f7818c23f26201bcefd9322613a", null ]
];