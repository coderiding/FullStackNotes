var interface_m_a_multi_point_item =
[
    [ "coordinate", "interface_m_a_multi_point_item.html#a1800044a2fc451a4ee9d34f5d4561117", null ],
    [ "customID", "interface_m_a_multi_point_item.html#adc5bf962fb1a9ae3716b94eb8adb80aa", null ],
    [ "subtitle", "interface_m_a_multi_point_item.html#a9977c2302696ea137ed47e6f13cd7723", null ],
    [ "title", "interface_m_a_multi_point_item.html#ab9db512100d274dfd85e03ab19544153", null ]
];