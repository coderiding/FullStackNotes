var interface_a_map_local_day_weather_forecast =
[
    [ "date", "interface_a_map_local_day_weather_forecast.html#a30e0bd92db32cd32dc6c89916e60cae8", null ],
    [ "dayPower", "interface_a_map_local_day_weather_forecast.html#aefe9e0e34339e46f1207cc23a9778000", null ],
    [ "dayTemp", "interface_a_map_local_day_weather_forecast.html#a540fd58a3a874dabc957471a0f829ba4", null ],
    [ "dayWeather", "interface_a_map_local_day_weather_forecast.html#a07dd0e42c485028eebf0c7615e283cf9", null ],
    [ "dayWind", "interface_a_map_local_day_weather_forecast.html#a1252f736e21b95d59183df064f53754e", null ],
    [ "nightPower", "interface_a_map_local_day_weather_forecast.html#a58833853db099760148aa03edacbaa7d", null ],
    [ "nightTemp", "interface_a_map_local_day_weather_forecast.html#a34d9c6b2ef39fa192533a4b6e1a8b8d8", null ],
    [ "nightWeather", "interface_a_map_local_day_weather_forecast.html#a6570e2a9631decb28b9ba72cb8375c9c", null ],
    [ "nightWind", "interface_a_map_local_day_weather_forecast.html#aab73ddcf91ea0ead3e7f32c6cb33ad86", null ],
    [ "week", "interface_a_map_local_day_weather_forecast.html#a0cfc56ec706023c35a471e68b2cc12c4", null ]
];