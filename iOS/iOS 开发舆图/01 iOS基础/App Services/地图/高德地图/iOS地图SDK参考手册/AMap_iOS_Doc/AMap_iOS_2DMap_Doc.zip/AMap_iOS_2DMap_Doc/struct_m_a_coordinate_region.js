var struct_m_a_coordinate_region =
[
    [ "center", "struct_m_a_coordinate_region.html#a65c4e9a756de79b3c3c3457942ec4712", null ],
    [ "span", "struct_m_a_coordinate_region.html#af63d9832b48a21924c0b9c9ec9e4a38c", null ]
];