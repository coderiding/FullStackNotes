var searchData=
[
  ['latitudedelta',['latitudeDelta',['../struct_m_a_coordinate_span.html#a1e46639e5970b5f462179b406961fa20',1,'MACoordinateSpan']]],
  ['longitudedelta',['longitudeDelta',['../struct_m_a_coordinate_span.html#a7945dec056c9b3ea520cfee32acaf2c4',1,'MACoordinateSpan']]]
];
