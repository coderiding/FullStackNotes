var interface_a_map_truck_route_search_request =
[
    [ "axis", "interface_a_map_truck_route_search_request.html#a7a4895363b7ca9c385276c21be063448", null ],
    [ "destinationId", "interface_a_map_truck_route_search_request.html#a85695abccbce829cb3b94e33e1002ed7", null ],
    [ "destinationtype", "interface_a_map_truck_route_search_request.html#a2d058b441b83ea11ba5f3be57e5f81d9", null ],
    [ "height", "interface_a_map_truck_route_search_request.html#a73ddf58444e542bfc1326f6f3c5a7038", null ],
    [ "load", "interface_a_map_truck_route_search_request.html#a7a1ede9b1092eb68fc324743fb65a9cb", null ],
    [ "originId", "interface_a_map_truck_route_search_request.html#ae891ce1dc58263b00aa6a71e3556274a", null ],
    [ "origintype", "interface_a_map_truck_route_search_request.html#a976a7d44489f79aedb17bac4877e59b0", null ],
    [ "plateNumber", "interface_a_map_truck_route_search_request.html#a8aa77ac82eeef77f6b583f76b5f8fb42", null ],
    [ "plateProvince", "interface_a_map_truck_route_search_request.html#a7148a9746ca7aa239ad7ceee636fbe10", null ],
    [ "size", "interface_a_map_truck_route_search_request.html#aa55927d2a892db08b13c29a91da03d5e", null ],
    [ "strategy", "interface_a_map_truck_route_search_request.html#aa452de0643d40d867ac3e0c492eee6a2", null ],
    [ "waypoints", "interface_a_map_truck_route_search_request.html#a626655a11dd7ec2d30afee1ee12b154e", null ],
    [ "weight", "interface_a_map_truck_route_search_request.html#a06c077845ad2148631e855537557ee2c", null ],
    [ "width", "interface_a_map_truck_route_search_request.html#a3093f52ea0871963c706275b764ddf22", null ]
];