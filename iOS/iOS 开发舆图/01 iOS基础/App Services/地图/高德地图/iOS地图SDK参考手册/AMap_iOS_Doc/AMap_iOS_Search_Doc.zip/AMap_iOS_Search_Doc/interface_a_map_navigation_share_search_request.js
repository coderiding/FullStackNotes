var interface_a_map_navigation_share_search_request =
[
    [ "destinationCoordinate", "interface_a_map_navigation_share_search_request.html#a89ead3a4529d1bb02e950165e881ab1c", null ],
    [ "startCoordinate", "interface_a_map_navigation_share_search_request.html#a19a78db8a93d728d18c92892ad0a0357", null ],
    [ "strategy", "interface_a_map_navigation_share_search_request.html#a76356522d9c284021955fbc95debc873", null ]
];