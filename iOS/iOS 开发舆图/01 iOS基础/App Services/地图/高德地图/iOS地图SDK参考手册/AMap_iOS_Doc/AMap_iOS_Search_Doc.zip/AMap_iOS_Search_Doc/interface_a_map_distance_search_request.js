var interface_a_map_distance_search_request =
[
    [ "destination", "interface_a_map_distance_search_request.html#a397f3307dd5f0d1f8be46cd8ed1f081f", null ],
    [ "origins", "interface_a_map_distance_search_request.html#a6f84ab61c605666fd5fa5a0a08a3dad6", null ],
    [ "type", "interface_a_map_distance_search_request.html#a1285e82790e3a4c6c4bce7ce11aba5b6", null ]
];