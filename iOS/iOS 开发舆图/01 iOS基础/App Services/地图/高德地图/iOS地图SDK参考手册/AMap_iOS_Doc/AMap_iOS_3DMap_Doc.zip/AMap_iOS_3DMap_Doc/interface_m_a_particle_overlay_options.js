var interface_m_a_particle_overlay_options =
[
    [ "duration", "interface_m_a_particle_overlay_options.html#ac32f08c8943f415655a0d717246c692e", null ],
    [ "icon", "interface_m_a_particle_overlay_options.html#a0b0f2aec97b42800da3dc8f0644eb003", null ],
    [ "loop", "interface_m_a_particle_overlay_options.html#aa509a9cfb57ceacf3df88ebebdc48bb5", null ],
    [ "maxParticles", "interface_m_a_particle_overlay_options.html#adc2ef03cc3fc5ceef62df637cef488a3", null ],
    [ "particleEmissionModule", "interface_m_a_particle_overlay_options.html#a8ca90bd26db2cd247f5127902c2a76e0", null ],
    [ "particleLifeTime", "interface_m_a_particle_overlay_options.html#ae12df561205171f64e1f1d65c16f0f6e", null ],
    [ "particleOverLifeModule", "interface_m_a_particle_overlay_options.html#a2b718e02e53b5acba57ef1c57dea4a1a", null ],
    [ "particleShapeModule", "interface_m_a_particle_overlay_options.html#a5b00f19c66bd2191b85bfc5cac634f4c", null ],
    [ "particleStartColor", "interface_m_a_particle_overlay_options.html#adef7ea4cf47b805ec97968cd75ff942b", null ],
    [ "particleStartSpeed", "interface_m_a_particle_overlay_options.html#a3e569a0406f341ffef82cfef40004bc3", null ],
    [ "startParticleSize", "interface_m_a_particle_overlay_options.html#abaf323be04947643bd58cd9ebb3b2790", null ],
    [ "visibile", "interface_m_a_particle_overlay_options.html#a7b7fd49869878e1e3a7064c35584de45", null ]
];