var interface_m_a_shape =
[
    [ "subtitle", "interface_m_a_shape.html#a8c593bba5991751c6ad08c66204b1c54", null ],
    [ "title", "interface_m_a_shape.html#a3c4e1927b0ce84ad0df66bdfbcb07468", null ]
];