var _a_map_u_r_l_search_type_8h =
[
    [ "AMapDrivingStrategy", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53c", [
      [ "AMapDrivingStrategyFastest", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53caac18e18988ecb27b984d9de44901422c", null ],
      [ "AMapDrivingStrategyMinFare", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53cae389cbd8591674cdb4dc6479a224a95d", null ],
      [ "AMapDrivingStrategyShortest", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53ca22bcefeaa233004ec26961e0991b5abe", null ],
      [ "AMapDrivingStrategyNoHighways", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53ca30040a84eb89f41bcb61b7463253ec88", null ],
      [ "AMapDrivingStrategyAvoidCongestion", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53ca5a5d1e58a28056861da5eeb29c5e9044", null ],
      [ "AMapDrivingStrategyAvoidHighwaysAndFare", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53cac8e026d04bf4caf61047c19208c6fcf6", null ],
      [ "AMapDrivingStrategyAvoidHighwaysAndCongestion", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53caed22805dd38b8f866a4ef9b86bf2e1a6", null ],
      [ "AMapDrivingStrategyAvoidFareAndCongestion", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53ca029fe6cbcd9496bc90a45a10d01d2ff1", null ],
      [ "AMapDrivingStrategyAvoidHighwaysAndFareAndCongestion", "_a_map_u_r_l_search_type_8h.html#a2a520cd6ef2e7581691a0285e235c53cab7ea10372e37bc3934d1e546bd3c35d8", null ]
    ] ],
    [ "AMapRouteSearchType", "_a_map_u_r_l_search_type_8h.html#a40b424a09c091a7e32fe3867799d65ea", [
      [ "AMapRouteSearchTypeDriving", "_a_map_u_r_l_search_type_8h.html#a40b424a09c091a7e32fe3867799d65eaa9e75d71b6ac0f01bbe265d4cecea3f5b", null ],
      [ "AMapRouteSearchTypeTransit", "_a_map_u_r_l_search_type_8h.html#a40b424a09c091a7e32fe3867799d65eaa3e8c4f4345f41355f81099d315ca4d33", null ],
      [ "AMapRouteSearchTypeWalking", "_a_map_u_r_l_search_type_8h.html#a40b424a09c091a7e32fe3867799d65eaa1eed899405c57c61ff28b6bbc818d456", null ]
    ] ],
    [ "AMapTransitStrategy", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4", [
      [ "AMapTransitStrategyFastest", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4a525b10b0a9c8129373405c80f4093e89", null ],
      [ "AMapTransitStrategyMinFare", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4ab6bc7687820a07ea139f208a733da341", null ],
      [ "AMapTransitStrategyMinTransfer", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4a00bbaeed2b3a005e0eecb1975bc33b9f", null ],
      [ "AMapTransitStrategyMinWalk", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4a4d367e9b43677b67674c0d18df238763", null ],
      [ "AMapTransitStrategyMostComfortable", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4a82ce4128e1c4749c99d52f9167f3f290", null ],
      [ "AMapTransitStrategyAvoidSubway", "_a_map_u_r_l_search_type_8h.html#ad1b905ff6533ab29c02df4cb812ba1d4acbe8da5970cfb2da1f49723b59e3f7bf", null ]
    ] ]
];