var interface_m_a_multi_polyline =
[
    [ "setPolylineWithCoordinates:count:drawStyleIndexes:", "interface_m_a_multi_polyline.html#a2d45e651415ed411548a0d85ac5c17fd", null ],
    [ "setPolylineWithPoints:count:drawStyleIndexes:", "interface_m_a_multi_polyline.html#ae8b4796ec5e4034b64cb12b83e4ea109", null ],
    [ "drawStyleIndexes", "interface_m_a_multi_polyline.html#af29a54f6a93a1d397eb00fdd533a4ccf", null ]
];