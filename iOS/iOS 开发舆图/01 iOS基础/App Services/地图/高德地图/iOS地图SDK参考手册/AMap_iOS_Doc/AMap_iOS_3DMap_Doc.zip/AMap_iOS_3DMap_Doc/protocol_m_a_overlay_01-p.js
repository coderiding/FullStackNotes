var protocol_m_a_overlay_01_p =
[
    [ "boundingMapRect", "protocol_m_a_overlay_01-p.html#a65b7395a389e6fc441512f78a1ab0ebd", null ],
    [ "coordinate", "protocol_m_a_overlay_01-p.html#a89886da8a4be2277c8ecf6d1e577decf", null ]
];