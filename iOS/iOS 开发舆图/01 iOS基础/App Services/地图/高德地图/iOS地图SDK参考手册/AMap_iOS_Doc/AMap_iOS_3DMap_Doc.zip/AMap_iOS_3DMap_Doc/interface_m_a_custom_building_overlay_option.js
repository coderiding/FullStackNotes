var interface_m_a_custom_building_overlay_option =
[
    [ "setOptionWithCoordinates:count:", "interface_m_a_custom_building_overlay_option.html#a6dbc017b29d3d6fca4f6ed5c2fe47b5b", null ],
    [ "height", "interface_m_a_custom_building_overlay_option.html#a67d24b2ea7c0fd68727ecaa72138f962", null ],
    [ "heightScale", "interface_m_a_custom_building_overlay_option.html#a83a2e099554013e6261362fb2cd89728", null ],
    [ "sideColor", "interface_m_a_custom_building_overlay_option.html#a51bbc7943f910c05fb76eac6dc92d5fa", null ],
    [ "topColor", "interface_m_a_custom_building_overlay_option.html#ac6dbbbcde5c255f6e5ad183b289d24b7", null ],
    [ "visibile", "interface_m_a_custom_building_overlay_option.html#ab9d7b0c47a1ffebd7daa5987581d1a01", null ]
];