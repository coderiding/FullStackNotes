var interface_m_a_heat_map_vector_overlay_render =
[
    [ "getHeatMapItem:", "interface_m_a_heat_map_vector_overlay_render.html#a70c40c49a765f492d3e5669ce9df281d", null ],
    [ "initWithHeatOverlay:", "interface_m_a_heat_map_vector_overlay_render.html#a8960895fffb125a862744bb71fbb23c5", null ],
    [ "heatOverlay", "interface_m_a_heat_map_vector_overlay_render.html#a8e0595f4b8b16931c5897e84eca0fca2", null ]
];