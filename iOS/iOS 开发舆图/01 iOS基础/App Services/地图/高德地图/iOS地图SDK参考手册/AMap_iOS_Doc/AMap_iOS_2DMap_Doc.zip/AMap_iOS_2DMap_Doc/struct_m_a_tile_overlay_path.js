var struct_m_a_tile_overlay_path =
[
    [ "contentScaleFactor", "struct_m_a_tile_overlay_path.html#a8886982cfab5b8ab11f623fc794ee172", null ],
    [ "x", "struct_m_a_tile_overlay_path.html#a3521132c303d4059ac107b30034a2865", null ],
    [ "y", "struct_m_a_tile_overlay_path.html#a0fd116e27092b36a61b57958f30d17f9", null ],
    [ "z", "struct_m_a_tile_overlay_path.html#a699773cba1edbcb6297e1d02e68f55d5", null ]
];