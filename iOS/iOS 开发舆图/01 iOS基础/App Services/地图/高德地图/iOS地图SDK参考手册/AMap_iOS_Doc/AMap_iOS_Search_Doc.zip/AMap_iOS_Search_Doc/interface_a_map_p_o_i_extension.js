var interface_a_map_p_o_i_extension =
[
    [ "cost", "interface_a_map_p_o_i_extension.html#a542d72874ca3d65472d25dcc043d4d52", null ],
    [ "openTime", "interface_a_map_p_o_i_extension.html#af4b72f9e230d7cf46c06549cae3387dd", null ],
    [ "rating", "interface_a_map_p_o_i_extension.html#a3fccefd1e3449765d07c7a60859ebf9a", null ]
];