var interface_m_a_particle_over_life_module =
[
    [ "setColorOverLife:", "interface_m_a_particle_over_life_module.html#a8acd3d0f5dbc0225d6fce72bddbe1bc9", null ],
    [ "setRotationOverLife:", "interface_m_a_particle_over_life_module.html#aca5d061481571cfd73a337f00adc55b1", null ],
    [ "setSizeOverLife:", "interface_m_a_particle_over_life_module.html#a7e155837f5a3e6ca3be09d766424a886", null ],
    [ "setVelocityOverLife:", "interface_m_a_particle_over_life_module.html#af0ed6d15756cd5448bb47d8180a7fef7", null ]
];