var interface_m_a_tile_overlay =
[
    [ "cancelLoadOfTileAtPath:", "interface_m_a_tile_overlay.html#a9b53840116e8603dfa76b8249f16035c", null ],
    [ "initWithURLTemplate:", "interface_m_a_tile_overlay.html#a2d1b7cd463837ceb3325833a793cad64", null ],
    [ "loadTileAtPath:result:", "interface_m_a_tile_overlay.html#a9ac5332855c624651d919d0270ee70e3", null ],
    [ "URLForTilePath:", "interface_m_a_tile_overlay.html#aacc5d904fedafb39cc635c042fa56599", null ],
    [ "boundingMapRect", "interface_m_a_tile_overlay.html#a769d8fc99b4862bc8c1a0991d096f914", null ],
    [ "canReplaceMapContent", "interface_m_a_tile_overlay.html#a6aac1f51da3f844794d7c1b334c807cc", null ],
    [ "disableOffScreenTileLoading", "interface_m_a_tile_overlay.html#abff0a1773022100b01441648e0b399c6", null ],
    [ "maximumZ", "interface_m_a_tile_overlay.html#a221f94bc4da2947ac558e9f21b4f9ed2", null ],
    [ "minimumZ", "interface_m_a_tile_overlay.html#a1248b62b980f16dcb24f28de6afdf8b7", null ],
    [ "tileSize", "interface_m_a_tile_overlay.html#aaa7c80906a1529680b45d5c306f74fcf", null ],
    [ "URLTemplate", "interface_m_a_tile_overlay.html#aaff14d9c454fae49ccf6b5d6160e9831", null ]
];