var interface_a_map_city =
[
    [ "adcode", "interface_a_map_city.html#a8e3e24d151392f84cb540d6e86d77844", null ],
    [ "city", "interface_a_map_city.html#a35af1d09262808542f1c587da9e91be1", null ],
    [ "citycode", "interface_a_map_city.html#aebfdcb8d08ccb7c7ede04bb8962a8305", null ],
    [ "districts", "interface_a_map_city.html#a2c02fb83e6cfdd622ca9c0ac4fa3b350", null ],
    [ "num", "interface_a_map_city.html#a9e3bf1c2727a752eda58fcb0dcd5e616", null ]
];