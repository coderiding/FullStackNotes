var interface_m_a_ground_overlay =
[
    [ "setGroundOverlayWithBounds:icon:", "interface_m_a_ground_overlay.html#ab2d2a78ef5672b44f7470f48b9046493", null ],
    [ "setGroundOverlayWithCoordinate:zoomLevel:icon:", "interface_m_a_ground_overlay.html#a931fdbb1bc79bf345a94e15ec29e50a0", null ],
    [ "alpha", "interface_m_a_ground_overlay.html#af27efb98e02cee91d287e1d14e5ecb91", null ],
    [ "bounds", "interface_m_a_ground_overlay.html#aedb61b591a8c4f53590df4611cd96881", null ],
    [ "icon", "interface_m_a_ground_overlay.html#a16cc9e834f8111c525c724282f09af04", null ],
    [ "zoomLevel", "interface_m_a_ground_overlay.html#a594f0473b7ff494110ac51e4121496f8", null ]
];