var interface_m_a_particle_overlay_renderer =
[
    [ "initWithParticleOverlay:", "interface_m_a_particle_overlay_renderer.html#a1fa5795cbfed23d97278faa39f011914", null ],
    [ "particleOverlay", "interface_m_a_particle_overlay_renderer.html#a31186469a885f1db2b63405470ff121b", null ]
];