var interface_a_map_traffic_road =
[
    [ "angle", "interface_a_map_traffic_road.html#a29ffb0a7e7315e5e59a6ffe536fe644b", null ],
    [ "direction", "interface_a_map_traffic_road.html#a069e0cb92d8ae7c9b0b5164386f4e4a6", null ],
    [ "name", "interface_a_map_traffic_road.html#aa7778d4cbc6829b0d8388e163c477a14", null ],
    [ "polyline", "interface_a_map_traffic_road.html#a2709e1ad5043b317d9576deebef9f474", null ],
    [ "speed", "interface_a_map_traffic_road.html#a57f0cf3b0d37ef2b9f5b770e306e5972", null ],
    [ "status", "interface_a_map_traffic_road.html#a9a864cab3e684f81616b71ab7aae71d8", null ]
];