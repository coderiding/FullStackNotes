var interface_m_a_custom_building_overlay =
[
    [ "addCustomOption:", "interface_m_a_custom_building_overlay.html#aaf88db3d88aff0779de6271ba21e8489", null ],
    [ "removeCustomOption:", "interface_m_a_custom_building_overlay.html#a3140e955293739a77d3ae700485f34c4", null ],
    [ "customOptions", "interface_m_a_custom_building_overlay.html#aaa755531c80884a758c995a0666a9e07", null ],
    [ "defaultOption", "interface_m_a_custom_building_overlay.html#affaf39e25120c78629825d961f99be46", null ]
];