var struct_m_a_map_point =
[
    [ "x", "struct_m_a_map_point.html#aa01bbb9ce5d2969a3e8bff9cddba9e2b", null ],
    [ "y", "struct_m_a_map_point.html#aa3222cb2e069b0f17f5fd9283e578918", null ]
];