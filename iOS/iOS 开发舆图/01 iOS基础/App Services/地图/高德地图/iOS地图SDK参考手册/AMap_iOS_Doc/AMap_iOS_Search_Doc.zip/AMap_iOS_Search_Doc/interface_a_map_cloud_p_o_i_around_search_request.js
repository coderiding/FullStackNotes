var interface_a_map_cloud_p_o_i_around_search_request =
[
    [ "center", "interface_a_map_cloud_p_o_i_around_search_request.html#a5057801b8e9c882a58cdbb2bd2836c68", null ],
    [ "keywords", "interface_a_map_cloud_p_o_i_around_search_request.html#aa4ea7596244cfa3e4603bef884529855", null ],
    [ "radius", "interface_a_map_cloud_p_o_i_around_search_request.html#a72a22439f9ef99337d48b7dfbdb4bbb3", null ]
];