var interface_m_a_user_location_representation =
[
    [ "fillColor", "interface_m_a_user_location_representation.html#a83cba8d31d2b4dbc97930405914b108b", null ],
    [ "image", "interface_m_a_user_location_representation.html#a79dcc6123bd0373ddbdbcbdf66f56708", null ],
    [ "lineDashPattern", "interface_m_a_user_location_representation.html#a17963c20bf29cf7ca2629af11e1e968b", null ],
    [ "lineWidth", "interface_m_a_user_location_representation.html#aac13b0ef8e3bb750634b82100ef05ce8", null ],
    [ "showsAccuracyRing", "interface_m_a_user_location_representation.html#a335bd4b04dd54bef9d07ca084aaf17ed", null ],
    [ "showsHeadingIndicator", "interface_m_a_user_location_representation.html#ad9704d0b7de9c9f8e87fa83533696f5d", null ],
    [ "strokeColor", "interface_m_a_user_location_representation.html#a57b35fd27da0224b78e489b4d1188646", null ]
];