var interface_m_a_particle_constant_rotation_generate =
[
    [ "initWithRotate:", "interface_m_a_particle_constant_rotation_generate.html#a35089bd00097aa3cadc822ba9d6134b8", null ]
];