var interface_m_a_map_status =
[
    [ "initWithCenterCoordinate:zoomLevel:rotationDegree:cameraDegree:screenAnchor:", "interface_m_a_map_status.html#a4066d63a9f7613e47ec96c33d774a1d9", null ],
    [ "cameraDegree", "interface_m_a_map_status.html#a6d8060a5c3768cf9c82eb4aa61309204", null ],
    [ "centerCoordinate", "interface_m_a_map_status.html#a2dd6a440fe6ea2dd6e90242cf5de1181", null ],
    [ "rotationDegree", "interface_m_a_map_status.html#ab6070681913a6ea09a91f6a716e01fdf", null ],
    [ "screenAnchor", "interface_m_a_map_status.html#ae83c120db5e9389bc19b003fee877de9", null ],
    [ "zoomLevel", "interface_m_a_map_status.html#a5e59924a7ce1cd23b21f35a475cc04cf", null ]
];