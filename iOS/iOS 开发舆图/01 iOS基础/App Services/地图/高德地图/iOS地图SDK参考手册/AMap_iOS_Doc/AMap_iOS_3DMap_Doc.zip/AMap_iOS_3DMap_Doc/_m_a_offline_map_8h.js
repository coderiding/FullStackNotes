var _m_a_offline_map_8h =
[
    [ "MAOfflineMap", "interface_m_a_offline_map.html", "interface_m_a_offline_map" ],
    [ "MAOfflineMap(Deprecated)", "category_m_a_offline_map_07_deprecated_08.html", "category_m_a_offline_map_07_deprecated_08" ],
    [ "MAOfflineMapDownloadBlock", "_m_a_offline_map_8h.html#ad54b8f9c9bddfc08ccec07e04fafb98c", null ],
    [ "MAOfflineMapNewestVersionBlock", "_m_a_offline_map_8h.html#a545bb0b3a03fe085265c6ca2cd3405d2", null ],
    [ "MAOfflineMapDownloadStatus", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59", [
      [ "MAOfflineMapDownloadStatusWaiting", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59aa8b6840958ef2f66d0d753da9d7a0c07", null ],
      [ "MAOfflineMapDownloadStatusStart", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a4bee64e188570216339b1c2b1e067d18", null ],
      [ "MAOfflineMapDownloadStatusProgress", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a80058867ed76b19ba346e457916b4fe9", null ],
      [ "MAOfflineMapDownloadStatusCompleted", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a91147b849b796177b96b34608c2e94db", null ],
      [ "MAOfflineMapDownloadStatusCancelled", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a2b15a7f5c1f2b93397f4ea2e42a6ddaa", null ],
      [ "MAOfflineMapDownloadStatusUnzip", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59ae3f1f70bfe62efdccdf64780d6877003", null ],
      [ "MAOfflineMapDownloadStatusFinished", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a7cca8e49d921faf92d688581320f56f7", null ],
      [ "MAOfflineMapDownloadStatusError", "_m_a_offline_map_8h.html#ab7941f9ffa2b8528cc239f4ef8417f59a1d746e4b3b98aa87d74bec577f88ebe0", null ]
    ] ],
    [ "MAOfflineMapError", "_m_a_offline_map_8h.html#a1dd881110342728bf2568c8971e7512b", [
      [ "MAOfflineMapErrorUnknown", "_m_a_offline_map_8h.html#a1dd881110342728bf2568c8971e7512ba9dfeb8613726e4785f2abdc1ba360e09", null ],
      [ "MAOfflineMapErrorCannotWriteToTmp", "_m_a_offline_map_8h.html#a1dd881110342728bf2568c8971e7512ba798d601f36dd0a72a3d36b371d80524e", null ],
      [ "MAOfflineMapErrorCannotOpenZipFile", "_m_a_offline_map_8h.html#a1dd881110342728bf2568c8971e7512bae0bdef935897841a18672b26caf07414", null ],
      [ "MAOfflineMapErrorCannotExpand", "_m_a_offline_map_8h.html#a1dd881110342728bf2568c8971e7512ba38765a37398846b9560f59de0b612204", null ]
    ] ],
    [ "MAOfflineMapDownloadExpectedSizeKey", "_m_a_offline_map_8h.html#a308db19dd083f5086d6d4bd0885d6ed3", null ],
    [ "MAOfflineMapDownloadReceivedSizeKey", "_m_a_offline_map_8h.html#aad3c2b6002f36fd974288f4907f6b819", null ],
    [ "MAOfflineMapErrorDomain", "_m_a_offline_map_8h.html#a17dcfbc5426cdb00b0ec5d6ce9429b5d", null ]
];