var interface_a_map_image =
[
    [ "title", "interface_a_map_image.html#a4764c78e8dce8d5ccce9683b52a8ac51", null ],
    [ "url", "interface_a_map_image.html#a6230b5e3a3919b2a3022c0c9a882d491", null ]
];