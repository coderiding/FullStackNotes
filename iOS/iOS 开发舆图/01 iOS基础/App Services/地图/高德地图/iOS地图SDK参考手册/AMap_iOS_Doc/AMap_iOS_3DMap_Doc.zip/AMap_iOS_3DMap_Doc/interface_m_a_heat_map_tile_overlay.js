var interface_m_a_heat_map_tile_overlay =
[
    [ "allowRetinaAdapting", "interface_m_a_heat_map_tile_overlay.html#a6c88677a3e79317da3757a17bcf8b92f", null ],
    [ "data", "interface_m_a_heat_map_tile_overlay.html#a1845655191242da3c7c7e05c0569b50f", null ],
    [ "gradient", "interface_m_a_heat_map_tile_overlay.html#acd616099e6d3dbdf62f266275a82e6cc", null ],
    [ "opacity", "interface_m_a_heat_map_tile_overlay.html#aa8ee98dd55d0f3e805f59208775b4bc8", null ],
    [ "radius", "interface_m_a_heat_map_tile_overlay.html#a1428aa743b389bcf09dbd9a01c06d7d8", null ]
];