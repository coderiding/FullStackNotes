var interface_m_a_trace_manager =
[
    [ "queryProcessedTraceWith:type:processingCallback:finishCallback:failedCallback:", "interface_m_a_trace_manager.html#ae5ccf179319b25aa9ee57dc2d1e62940", null ],
    [ "start", "interface_m_a_trace_manager.html#a6565eb0a53433b0ffa3957d29828e547", null ],
    [ "startTraceWith:", "interface_m_a_trace_manager.html#af7d61da69eb5fae3ba7f44d1930b78ee", null ],
    [ "stop", "interface_m_a_trace_manager.html#af5a64ade160b692195f9814c33395d71", null ],
    [ "stopTrace", "interface_m_a_trace_manager.html#a2a9156bb98a49cb431c080104407b0fb", null ],
    [ "delegate", "interface_m_a_trace_manager.html#ae8bb17b92f8bcef9c825f563e16967aa", null ]
];