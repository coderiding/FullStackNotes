var protocol_m_a_animatable_annotation_01_p =
[
    [ "isAnimationFinished", "protocol_m_a_animatable_annotation_01-p.html#a1f77e53e0ba98a7ff46b1318ee5637cd", null ],
    [ "rotateDegree", "protocol_m_a_animatable_annotation_01-p.html#a8e0e876a6f1c3b11cb4e9c5686d7532a", null ],
    [ "shouldAnimationStart", "protocol_m_a_animatable_annotation_01-p.html#abc33a82423ca51d86784f5a6fc628608", null ],
    [ "step:", "protocol_m_a_animatable_annotation_01-p.html#ab124a7715c1faa3673cd8da7a173d18d", null ]
];