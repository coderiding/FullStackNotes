var interface_m_a_particle_random_color_generate =
[
    [ "initWithBoundaryColorR1:G1:B1:A1:R2:G2:B2:A2:", "interface_m_a_particle_random_color_generate.html#adcd51e255106462debf34a8c82d2766a", null ]
];