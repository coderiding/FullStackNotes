var _a_map_foundation_const_8h =
[
    [ "AMapFoundationNSErrorCloudConfigDisabel", "_a_map_foundation_const_8h.html#a8f222691944637244128329905b9c4dc", null ],
    [ "AMapFoundationNSErrorCloudConfigDisabelCode", "_a_map_foundation_const_8h.html#a98fbeed106db984713544db0b8a554d1", null ],
    [ "AMapFoundationNSErrorCode", "_a_map_foundation_const_8h.html#ac279f8c937b71a9a91fb6bb81742f223", null ],
    [ "AMapFoundationNSErrorCurrentUploadSizeHaveExcess", "_a_map_foundation_const_8h.html#af6e5f605c39335ef7212c62dd723f4a2", null ],
    [ "AMapFoundationNSErrorCurrentUploadSizeHaveExcessCode", "_a_map_foundation_const_8h.html#acfd067af710642309704c83d316c9709", null ],
    [ "AMapFoundationNSErrorCurrentworkIsRunning", "_a_map_foundation_const_8h.html#abda8e50f4bb41e4c95cee51b0994bc7d", null ],
    [ "AMapFoundationNSErrorCurrentworkIsRunningCode", "_a_map_foundation_const_8h.html#a25a7282f34bcefd6af0da4191696c751", null ],
    [ "AMapFoundationNSErrorFileDonotExist", "_a_map_foundation_const_8h.html#af6e1be88eb3f043a744e05d1466eb605", null ],
    [ "AMapFoundationNSErrorFileDonotExistCode", "_a_map_foundation_const_8h.html#a3e5f7fc17dfb981a056b09123034f890", null ],
    [ "AMapFoundationNSErrorFilePathInvaild", "_a_map_foundation_const_8h.html#ab45656888abb048d01c184f8009b9caf", null ],
    [ "AMapFoundationNSErrorFilePathInvaildCode", "_a_map_foundation_const_8h.html#a06440b3e16858173d596f5c3a8bc74a9", null ],
    [ "AMapFoundationNSErrorNetworkUnusable", "_a_map_foundation_const_8h.html#a8b9073f7d2cf7e4b54b252b3853e1f14", null ],
    [ "AMapFoundationNSErrorNetworkUnusableCode", "_a_map_foundation_const_8h.html#a2dd5f38cee500108b5c70e87faf97979", null ],
    [ "AMapFoundationNSErrorParametersInvalid", "_a_map_foundation_const_8h.html#ada6efad61e4725f5e141fd5c197efd16", null ],
    [ "AMapFoundationNSErrorParametersInvalidCode", "_a_map_foundation_const_8h.html#a2329bd1695e32815224f6a78f755b02e", null ],
    [ "AMapFoundationNSErrorTypeLogDonotExist", "_a_map_foundation_const_8h.html#ab6730594474203eaf2b1c37053b3858a", null ],
    [ "AMapFoundationNSErrorTypeLogDonotExistCode", "_a_map_foundation_const_8h.html#a709de49e576556d6ffdf9eb1372eed0d", null ],
    [ "AMapFoundationNSErrorUploadDataIsEmpty", "_a_map_foundation_const_8h.html#a5a967a5e6e5ed559eaa8b1bf90a27137", null ],
    [ "AMapFoundationNSErrorUploadDataIsEmptyCode", "_a_map_foundation_const_8h.html#a2374f85461b667face3353c39967d7ee", null ]
];