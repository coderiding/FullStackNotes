var annotated_dup =
[
    [ "AMapNaviConfig", "interface_a_map_navi_config.html", "interface_a_map_navi_config" ],
    [ "AMapPOIConfig", "interface_a_map_p_o_i_config.html", "interface_a_map_p_o_i_config" ],
    [ "AMapRouteConfig", "interface_a_map_route_config.html", "interface_a_map_route_config" ],
    [ "AMapServices", "interface_a_map_services.html", "interface_a_map_services" ],
    [ "AMapURLSearch", "interface_a_map_u_r_l_search.html", null ]
];