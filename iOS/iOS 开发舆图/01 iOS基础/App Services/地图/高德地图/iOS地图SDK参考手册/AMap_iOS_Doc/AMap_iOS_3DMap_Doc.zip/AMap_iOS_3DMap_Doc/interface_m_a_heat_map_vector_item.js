var interface_m_a_heat_map_vector_item =
[
    [ "center", "interface_m_a_heat_map_vector_item.html#a75d25e70aaccbffd09bfe11dd7943200", null ],
    [ "intensity", "interface_m_a_heat_map_vector_item.html#a811f1d36cda04b32c19ee8574456a06a", null ],
    [ "nodeIndices", "interface_m_a_heat_map_vector_item.html#a4d5c8dc701f11217d14e0a1963992aa0", null ]
];