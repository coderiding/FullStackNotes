var interface_a_map_location_share_search_request =
[
    [ "location", "interface_a_map_location_share_search_request.html#aad534ccf69d8b36fa3557ed9e38139ac", null ],
    [ "name", "interface_a_map_location_share_search_request.html#a50f07e4d21d58655276233fd8c25431e", null ]
];