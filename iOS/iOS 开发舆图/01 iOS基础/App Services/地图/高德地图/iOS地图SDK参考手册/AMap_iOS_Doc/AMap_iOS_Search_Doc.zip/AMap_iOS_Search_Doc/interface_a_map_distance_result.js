var interface_a_map_distance_result =
[
    [ "code", "interface_a_map_distance_result.html#a0affcd8d2ac14dd3e686fe1c5211a6c7", null ],
    [ "destID", "interface_a_map_distance_result.html#a617ec936538cf1cad76f530e14db2f7e", null ],
    [ "distance", "interface_a_map_distance_result.html#a3aecd58bb67868d93fd4a7705d87f0c6", null ],
    [ "duration", "interface_a_map_distance_result.html#a8a11e86b87fe2e083543938956adf85f", null ],
    [ "info", "interface_a_map_distance_result.html#a4bedfbaa98bed32b1cae3c1a8c1330a5", null ],
    [ "originID", "interface_a_map_distance_result.html#a82af8f98444deeb8fd792d32bf34719f", null ]
];