var interface_m_a_particle_curve_size_generate =
[
    [ "initWithCurveX:Y:Z:", "interface_m_a_particle_curve_size_generate.html#ae5471031e62328fa895d83c3a1080d2a", null ]
];