var interface_a_map_weather_search_request =
[
    [ "city", "interface_a_map_weather_search_request.html#a30d807f7e1f0a1361aa70f40a5a62c9e", null ],
    [ "type", "interface_a_map_weather_search_request.html#a48dd82e7f970caa616d6534595bbba02", null ]
];