var interface_a_map_traffic_info =
[
    [ "evaluation", "interface_a_map_traffic_info.html#a9a6141afec9cbc5b803d04e47df9fd3a", null ],
    [ "roads", "interface_a_map_traffic_info.html#a2830d53ef440502c7edd69a513b94fcd", null ],
    [ "statusDescription", "interface_a_map_traffic_info.html#a9164b04dd5dda058e7152ea844a761c3", null ]
];