var category_m_a_map_view_07_location_option_08 =
[
    [ "allowsBackgroundLocationUpdates", "category_m_a_map_view_07_location_option_08.html#a8c9a430c77774e313d3dabe8756feebc", null ],
    [ "desiredAccuracy", "category_m_a_map_view_07_location_option_08.html#a1702c8271362b33dc834efca06e6742a", null ],
    [ "distanceFilter", "category_m_a_map_view_07_location_option_08.html#aa82691ebaadbef2bccde63caf64cf7da", null ],
    [ "headingFilter", "category_m_a_map_view_07_location_option_08.html#ab2513137778b7351e569884a379ca2f1", null ],
    [ "pausesLocationUpdatesAutomatically", "category_m_a_map_view_07_location_option_08.html#addbbebc78596188078c6821c606eecfb", null ]
];