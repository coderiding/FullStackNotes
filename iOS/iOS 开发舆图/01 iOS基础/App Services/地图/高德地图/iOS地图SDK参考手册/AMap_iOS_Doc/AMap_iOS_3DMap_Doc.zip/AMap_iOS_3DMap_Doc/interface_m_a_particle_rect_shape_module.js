var interface_m_a_particle_rect_shape_module =
[
    [ "initWithLeft:top:right:bottom:useRatio:", "interface_m_a_particle_rect_shape_module.html#aa86fa5e4e36a6d74c7c2f633fe06a4af", null ]
];