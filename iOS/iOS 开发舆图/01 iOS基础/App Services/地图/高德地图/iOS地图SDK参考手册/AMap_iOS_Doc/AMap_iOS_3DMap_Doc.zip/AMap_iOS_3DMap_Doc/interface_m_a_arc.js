var interface_m_a_arc =
[
    [ "boundingMapRect", "interface_m_a_arc.html#a9d605525c9028cf48d47b56bc27d2816", null ],
    [ "endCoordinate", "interface_m_a_arc.html#a88c5c20654ca7a87732ac35bd10c0b27", null ],
    [ "passedCoordinate", "interface_m_a_arc.html#a6e0964068508dfb0ac5ef8d7057a0cc6", null ],
    [ "startCoordinate", "interface_m_a_arc.html#acc24b30fa5ef87469baf71b233319f75", null ]
];