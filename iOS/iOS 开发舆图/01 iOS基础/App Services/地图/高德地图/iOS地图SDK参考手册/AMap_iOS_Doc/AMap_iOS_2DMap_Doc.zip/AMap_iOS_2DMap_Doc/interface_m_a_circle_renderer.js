var interface_m_a_circle_renderer =
[
    [ "initWithCircle:", "interface_m_a_circle_renderer.html#a0841cf581a1982d2dd4ad3fa9b13c9c6", null ],
    [ "circle", "interface_m_a_circle_renderer.html#ad97e2ccacd48360d221ab156880b3331", null ]
];