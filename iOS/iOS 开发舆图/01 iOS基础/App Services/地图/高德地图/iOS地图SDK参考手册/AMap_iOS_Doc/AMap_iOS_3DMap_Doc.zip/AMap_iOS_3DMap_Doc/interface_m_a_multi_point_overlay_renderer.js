var interface_m_a_multi_point_overlay_renderer =
[
    [ "initWithMultiPointOverlay:", "interface_m_a_multi_point_overlay_renderer.html#af157df88b418af7e40990a21e70e3829", null ],
    [ "anchor", "interface_m_a_multi_point_overlay_renderer.html#adc030d50045beeb2c2bd8b24816cb515", null ],
    [ "delegate", "interface_m_a_multi_point_overlay_renderer.html#a4f0aedf8f3c53807f22ee3bfc06e690c", null ],
    [ "icon", "interface_m_a_multi_point_overlay_renderer.html#aba7abca62e09ba571c964c9b790e7cba", null ],
    [ "multiPointOverlay", "interface_m_a_multi_point_overlay_renderer.html#ad83897a9fa33e166a7fe6e53253dc54a", null ],
    [ "pointSize", "interface_m_a_multi_point_overlay_renderer.html#aa416986052fc872e9e31ccb55ec4510a", null ]
];