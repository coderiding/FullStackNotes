var interface_a_map_cloud_p_o_i_local_search_request =
[
    [ "city", "interface_a_map_cloud_p_o_i_local_search_request.html#ac4dd401370a24933e6500a29bf49b418", null ],
    [ "keywords", "interface_a_map_cloud_p_o_i_local_search_request.html#a5d449d63ed9258492b0eaa3e213da395", null ]
];