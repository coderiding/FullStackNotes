var interface_a_map_railway =
[
    [ "alters", "interface_a_map_railway.html#a9aab79ccab3ebe8155db3613e523a333", null ],
    [ "arrivalStation", "interface_a_map_railway.html#a7263f5693a3968b5b44df28f6de7bcae", null ],
    [ "departureStation", "interface_a_map_railway.html#af3539400f36c1184bb59a86fefc2a801", null ],
    [ "distance", "interface_a_map_railway.html#a4f3651510025f3de1d2c21fff7c7291f", null ],
    [ "name", "interface_a_map_railway.html#afa8986b22f989152a4dfa16680d72cb6", null ],
    [ "spaces", "interface_a_map_railway.html#a3a5c7b57afa722b36f78480fef2794bf", null ],
    [ "time", "interface_a_map_railway.html#a36a5e2f4659c3be40c8647282a9bcf86", null ],
    [ "trip", "interface_a_map_railway.html#a960fbe5f239c11d96bf85a0314de79c3", null ],
    [ "type", "interface_a_map_railway.html#add65d44233bb799168e0a8b501ca50c0", null ],
    [ "uid", "interface_a_map_railway.html#a0bc0ca5bcfa16f2463576440f9b27da3", null ],
    [ "viaStops", "interface_a_map_railway.html#ae7607ce65f93fb30721715cae5ea7ee1", null ]
];