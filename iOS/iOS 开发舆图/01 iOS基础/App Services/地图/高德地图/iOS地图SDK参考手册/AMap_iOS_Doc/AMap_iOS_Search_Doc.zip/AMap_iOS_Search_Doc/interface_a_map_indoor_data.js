var interface_a_map_indoor_data =
[
    [ "floor", "interface_a_map_indoor_data.html#a529c6f749dadf1822cc90d09c551e489", null ],
    [ "floorName", "interface_a_map_indoor_data.html#af2b5a60c5e952362d561a09e9c4c5794", null ],
    [ "pid", "interface_a_map_indoor_data.html#a6e5467a390a08a097e428ed8cc148ebe", null ]
];