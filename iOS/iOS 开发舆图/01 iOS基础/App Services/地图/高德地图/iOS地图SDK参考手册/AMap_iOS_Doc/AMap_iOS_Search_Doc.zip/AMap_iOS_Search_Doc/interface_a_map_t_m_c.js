var interface_a_map_t_m_c =
[
    [ "distance", "interface_a_map_t_m_c.html#ad07429a2b88d69b12aca30db58a6ccc0", null ],
    [ "polyline", "interface_a_map_t_m_c.html#a13cfa77d16af5c824bade974c6f3ddd2", null ],
    [ "status", "interface_a_map_t_m_c.html#abdbc2ad2b8fc89c4125b31932081ab03", null ]
];