var interface_a_map_district_search_request =
[
    [ "keywords", "interface_a_map_district_search_request.html#ac85179301f732e21d901b2e989719f74", null ],
    [ "offset", "interface_a_map_district_search_request.html#a53a17098826390c34128b78a13803844", null ],
    [ "page", "interface_a_map_district_search_request.html#aa3f2a909e86a955f396a211be6c40537", null ],
    [ "requireExtension", "interface_a_map_district_search_request.html#a6f9f010ba86b92909dae3c7dad37a500", null ],
    [ "showBusinessArea", "interface_a_map_district_search_request.html#a4b6093583793bc31f4e929ff485b1780", null ],
    [ "subdistrict", "interface_a_map_district_search_request.html#a742a5bb4635638034e9abb0f6d894c18", null ]
];