var searchData=
[
  ['getlatestamapapp',['getLatestAMapApp',['../interface_a_map_u_r_l_search.html#acabb73bf7fd0f2bda40fa2dbd9152f80',1,'AMapURLSearch']]]
];
