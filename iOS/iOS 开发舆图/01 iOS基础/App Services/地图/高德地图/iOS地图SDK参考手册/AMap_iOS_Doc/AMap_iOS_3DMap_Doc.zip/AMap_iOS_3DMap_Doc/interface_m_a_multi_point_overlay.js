var interface_m_a_multi_point_overlay =
[
    [ "initWithMultiPointItems:", "interface_m_a_multi_point_overlay.html#a66912e0f9d82cd1816e17f8b02e1d98f", null ],
    [ "items", "interface_m_a_multi_point_overlay.html#a8873c90210200f5bd66e5d5035472c45", null ]
];