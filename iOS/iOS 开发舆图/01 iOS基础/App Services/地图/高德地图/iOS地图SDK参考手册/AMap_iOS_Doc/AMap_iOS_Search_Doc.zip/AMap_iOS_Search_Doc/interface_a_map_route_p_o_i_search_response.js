var interface_a_map_route_p_o_i_search_response =
[
    [ "count", "interface_a_map_route_p_o_i_search_response.html#af32d9a7a29a3aaf6ead1c850246a27b1", null ],
    [ "pois", "interface_a_map_route_p_o_i_search_response.html#a58cc63cece5b494f5d579286213a9a6c", null ]
];