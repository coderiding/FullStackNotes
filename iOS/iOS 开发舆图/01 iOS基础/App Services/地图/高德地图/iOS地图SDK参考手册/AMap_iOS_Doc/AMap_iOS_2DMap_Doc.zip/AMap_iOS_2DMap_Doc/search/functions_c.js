var searchData=
[
  ['takesnapshotinrect_3a',['takeSnapshotInRect:',['../category_m_a_map_view_07_snapshot_08.html#a184e6408f2eff4a2f58ea779c63845a2',1,'MAMapView(Snapshot)::takeSnapshotInRect:()'],['../interface_m_a_map_view.html#a184e6408f2eff4a2f58ea779c63845a2',1,'MAMapView::takeSnapshotInRect:()']]],
  ['takesnapshotinrect_3awithcompletionblock_3a',['takeSnapshotInRect:withCompletionBlock:',['../category_m_a_map_view_07_snapshot_08.html#aeb8e84a872ce9c498ba517c6ac7d8520',1,'MAMapView(Snapshot)::takeSnapshotInRect:withCompletionBlock:()'],['../interface_m_a_map_view.html#aeb8e84a872ce9c498ba517c6ac7d8520',1,'MAMapView::takeSnapshotInRect:withCompletionBlock:()']]]
];
