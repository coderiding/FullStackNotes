var interface_m_a_animated_annotation =
[
    [ "addMoveAnimationWithKeyCoordinates:count:withDuration:withName:completeCallback:", "interface_m_a_animated_annotation.html#a1e707267c7db26af8ce0f92e6a255579", null ],
    [ "addMoveAnimationWithKeyCoordinates:count:withDuration:withName:completeCallback:stepCallback:", "interface_m_a_animated_annotation.html#a0a2c901e0dd1f55980bc99dfc731d674", null ],
    [ "allMoveAnimations", "interface_m_a_animated_annotation.html#a39c79e6e542a67041c0d44ebb907ebbb", null ],
    [ "setNeedsStart", "interface_m_a_animated_annotation.html#a7d855117183181feb1068ebecaad8b92", null ],
    [ "movingDirection", "interface_m_a_animated_annotation.html#ab80b10c6c31cca2236a6e8d7ede12b47", null ]
];