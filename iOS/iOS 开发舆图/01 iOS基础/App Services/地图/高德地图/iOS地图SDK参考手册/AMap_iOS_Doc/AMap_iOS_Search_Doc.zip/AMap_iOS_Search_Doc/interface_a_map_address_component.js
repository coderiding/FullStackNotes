var interface_a_map_address_component =
[
    [ "adcode", "interface_a_map_address_component.html#a43d6d0f4d8713c5523f7a878701da7d8", null ],
    [ "building", "interface_a_map_address_component.html#a389ae9c7983e600eb85bac011f4029b5", null ],
    [ "businessAreas", "interface_a_map_address_component.html#af09996c100433e3dac1779eac5fa934e", null ],
    [ "city", "interface_a_map_address_component.html#a174e70f776a2a635c24a84f46b45d757", null ],
    [ "citycode", "interface_a_map_address_component.html#a4c662fff9a0df21549d3b70537868077", null ],
    [ "country", "interface_a_map_address_component.html#a64ac759f7489923385203bade34649fa", null ],
    [ "countryCode", "interface_a_map_address_component.html#a7fc48b9ed36ec05fd81aa110bc0881a8", null ],
    [ "district", "interface_a_map_address_component.html#a4211ca2815fa652975bf6486c437e1a4", null ],
    [ "neighborhood", "interface_a_map_address_component.html#a258d0e76aab74b61b5071601bbe7370b", null ],
    [ "province", "interface_a_map_address_component.html#af56c7984016d644acfeb617b1ad8dee4", null ],
    [ "streetNumber", "interface_a_map_address_component.html#a1068680bdfee1af22a06ed67eef63053", null ],
    [ "towncode", "interface_a_map_address_component.html#a23ff10b6c81d0dd984188186ca6475c4", null ],
    [ "township", "interface_a_map_address_component.html#a168f8c34f3b0928ca32a9abd6fb127dc", null ]
];