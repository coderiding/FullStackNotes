var interface_a_map_p_o_i_around_search_request =
[
    [ "city", "interface_a_map_p_o_i_around_search_request.html#a1792259f5c4d6cd8fc928ffa65a04be0", null ],
    [ "keywords", "interface_a_map_p_o_i_around_search_request.html#afe61728f0e196a3cf7e0c85c9608741c", null ],
    [ "location", "interface_a_map_p_o_i_around_search_request.html#a3fdd8c619dc89448752fad4a1cf003dc", null ],
    [ "radius", "interface_a_map_p_o_i_around_search_request.html#a203d07bfb1c0683e834bd95ebcfcf041", null ]
];