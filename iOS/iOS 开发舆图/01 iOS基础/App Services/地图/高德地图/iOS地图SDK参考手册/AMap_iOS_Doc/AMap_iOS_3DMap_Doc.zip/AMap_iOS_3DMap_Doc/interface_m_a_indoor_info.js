var interface_m_a_indoor_info =
[
    [ "activeFloorIndex", "interface_m_a_indoor_info.html#a86e381fafc37567e0482bd859912d735", null ],
    [ "activeFloorInfoIndex", "interface_m_a_indoor_info.html#ab8d5545e8b584a76ab6d7b6e144bdfed", null ],
    [ "buildingType", "interface_m_a_indoor_info.html#ac1f460895a78752035c382fe139c9d75", null ],
    [ "cnName", "interface_m_a_indoor_info.html#aabcc778fc17cc152f47bf3f73155580b", null ],
    [ "enName", "interface_m_a_indoor_info.html#a61aca41e3c7684a3586c7558867bd341", null ],
    [ "floorInfo", "interface_m_a_indoor_info.html#aae1c1c27ff88966d5ad0a7b6f006a95d", null ],
    [ "numberOfFloor", "interface_m_a_indoor_info.html#afcb05d360978674513085eed458401b0", null ],
    [ "numberOfParkFloor", "interface_m_a_indoor_info.html#a000a8228bfd2be9b8269acbc6c40c781", null ],
    [ "poiID", "interface_m_a_indoor_info.html#a01f18ab2251520ed2b36109271ed3a5f", null ]
];