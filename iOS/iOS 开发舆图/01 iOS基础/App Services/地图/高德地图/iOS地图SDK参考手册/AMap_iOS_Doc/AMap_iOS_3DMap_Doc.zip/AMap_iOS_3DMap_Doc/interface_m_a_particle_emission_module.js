var interface_m_a_particle_emission_module =
[
    [ "initWithEmissionRate:rateTime:", "interface_m_a_particle_emission_module.html#a4651852b9558033dbaba00a4b361669b", null ]
];