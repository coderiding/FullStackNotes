var interface_m_a_custom_building_overlay_renderer =
[
    [ "initWithCustomBuildingOverlay:", "interface_m_a_custom_building_overlay_renderer.html#a249816374c4236839024d816e755c23d", null ],
    [ "customBuildingOverlay", "interface_m_a_custom_building_overlay_renderer.html#a321b935dcd465b13f40e3040345ee22d", null ]
];