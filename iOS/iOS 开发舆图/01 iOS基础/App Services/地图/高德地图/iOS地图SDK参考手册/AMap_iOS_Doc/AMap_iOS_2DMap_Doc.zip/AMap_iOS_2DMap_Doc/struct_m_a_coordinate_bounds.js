var struct_m_a_coordinate_bounds =
[
    [ "northEast", "struct_m_a_coordinate_bounds.html#ac3dfce338a50f0ba602d823731271c28", null ],
    [ "southWest", "struct_m_a_coordinate_bounds.html#af960ce7cd42c367c5a849c00c1cd7909", null ]
];