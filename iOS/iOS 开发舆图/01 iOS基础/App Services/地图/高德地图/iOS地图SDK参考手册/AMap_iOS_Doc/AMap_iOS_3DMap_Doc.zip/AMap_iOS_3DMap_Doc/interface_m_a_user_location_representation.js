var interface_m_a_user_location_representation =
[
    [ "enablePulseAnnimation", "interface_m_a_user_location_representation.html#a06f6f0f635bffed69d426a9b86512baf", null ],
    [ "fillColor", "interface_m_a_user_location_representation.html#a83cba8d31d2b4dbc97930405914b108b", null ],
    [ "image", "interface_m_a_user_location_representation.html#a79dcc6123bd0373ddbdbcbdf66f56708", null ],
    [ "lineWidth", "interface_m_a_user_location_representation.html#aac13b0ef8e3bb750634b82100ef05ce8", null ],
    [ "locationDotBgColor", "interface_m_a_user_location_representation.html#a95edd954f6331958f07b79f1c715f11e", null ],
    [ "locationDotFillColor", "interface_m_a_user_location_representation.html#a6f20abc02a8bf63bff533a5ec9f128b5", null ],
    [ "showsAccuracyRing", "interface_m_a_user_location_representation.html#a335bd4b04dd54bef9d07ca084aaf17ed", null ],
    [ "showsHeadingIndicator", "interface_m_a_user_location_representation.html#ad9704d0b7de9c9f8e87fa83533696f5d", null ],
    [ "strokeColor", "interface_m_a_user_location_representation.html#a57b35fd27da0224b78e489b4d1188646", null ]
];