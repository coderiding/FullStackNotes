var interface_a_map_road_traffic_circle_search_request =
[
    [ "location", "interface_a_map_road_traffic_circle_search_request.html#af7bec82cbe78fb55f0fca66b6ad0c3a7", null ],
    [ "radius", "interface_a_map_road_traffic_circle_search_request.html#adfda62d59305b6535d0b7150e5df4e9d", null ]
];