var interface_a_map_sub_p_o_i =
[
    [ "address", "interface_a_map_sub_p_o_i.html#a5996b0e9ecd2f7a5a1f1d820b212b2b3", null ],
    [ "distance", "interface_a_map_sub_p_o_i.html#a558d1af1bdcf9f0593612d9fd61f3330", null ],
    [ "location", "interface_a_map_sub_p_o_i.html#a889f8ff19cfbdf1b60781034c553fea2", null ],
    [ "name", "interface_a_map_sub_p_o_i.html#aae3831029e4892cc868be9c78729912c", null ],
    [ "sname", "interface_a_map_sub_p_o_i.html#a4a8ef66c3a7b9897db6c934323f1abb6", null ],
    [ "subtype", "interface_a_map_sub_p_o_i.html#a5a4c61023865637694214f56583da102", null ],
    [ "uid", "interface_a_map_sub_p_o_i.html#a46b34051db1dfd0bb3c19aebaf942318", null ]
];