var searchData=
[
  ['initwithcenter_3aradius_3aidentifier_3a',['initWithCenter:radius:identifier:',['../interface_a_map_location_circle_region.html#a13dd822b0f65e027d99a061f6d641eef',1,'AMapLocationCircleRegion']]],
  ['initwithcoordinates_3acount_3aidentifier_3a',['initWithCoordinates:count:identifier:',['../interface_a_map_location_polygon_region.html#a7b58e9529b6616626da5cd82797d4728',1,'AMapLocationPolygonRegion']]],
  ['initwithidentifier_3a',['initWithIdentifier:',['../interface_a_map_location_region.html#a317409b5da050f7f83f3082b87fbe868',1,'AMapLocationRegion']]]
];
