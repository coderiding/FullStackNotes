var interface_a_map_location_circle_region =
[
    [ "initWithCenter:radius:identifier:", "interface_a_map_location_circle_region.html#a13dd822b0f65e027d99a061f6d641eef", null ],
    [ "center", "interface_a_map_location_circle_region.html#a095412c9ff5b692a8bca55e5578b8e03", null ],
    [ "radius", "interface_a_map_location_circle_region.html#a379663cd2741d56dd55e84d82a4227aa", null ]
];