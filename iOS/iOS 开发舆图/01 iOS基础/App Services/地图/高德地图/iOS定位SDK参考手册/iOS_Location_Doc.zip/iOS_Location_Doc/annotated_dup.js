var annotated_dup =
[
    [ "AMapGeoFenceCircleRegion", "interface_a_map_geo_fence_circle_region.html", "interface_a_map_geo_fence_circle_region" ],
    [ "AMapGeoFenceDistrictRegion", "interface_a_map_geo_fence_district_region.html", "interface_a_map_geo_fence_district_region" ],
    [ "AMapGeoFenceManager", "interface_a_map_geo_fence_manager.html", "interface_a_map_geo_fence_manager" ],
    [ "<AMapGeoFenceManagerDelegate >", "protocol_a_map_geo_fence_manager_delegate_01-p.html", "protocol_a_map_geo_fence_manager_delegate_01-p" ],
    [ "AMapGeoFencePOIRegion", "interface_a_map_geo_fence_p_o_i_region.html", "interface_a_map_geo_fence_p_o_i_region" ],
    [ "AMapGeoFencePolygonRegion", "interface_a_map_geo_fence_polygon_region.html", "interface_a_map_geo_fence_polygon_region" ],
    [ "AMapGeoFenceRegion", "interface_a_map_geo_fence_region.html", "interface_a_map_geo_fence_region" ],
    [ "AMapLocationCircleRegion", "interface_a_map_location_circle_region.html", "interface_a_map_location_circle_region" ],
    [ "AMapLocationDistrictItem", "interface_a_map_location_district_item.html", "interface_a_map_location_district_item" ],
    [ "AMapLocationManager", "interface_a_map_location_manager.html", "interface_a_map_location_manager" ],
    [ "<AMapLocationManagerDelegate >", "protocol_a_map_location_manager_delegate_01-p.html", "protocol_a_map_location_manager_delegate_01-p" ],
    [ "AMapLocationPOIItem", "interface_a_map_location_p_o_i_item.html", "interface_a_map_location_p_o_i_item" ],
    [ "AMapLocationPoint", "interface_a_map_location_point.html", "interface_a_map_location_point" ],
    [ "AMapLocationPolygonRegion", "interface_a_map_location_polygon_region.html", "interface_a_map_location_polygon_region" ],
    [ "AMapLocationReGeocode", "interface_a_map_location_re_geocode.html", "interface_a_map_location_re_geocode" ],
    [ "AMapLocationRegion", "interface_a_map_location_region.html", "interface_a_map_location_region" ]
];