var interface_a_map_geo_fence_circle_region =
[
    [ "center", "interface_a_map_geo_fence_circle_region.html#a097b0eefa35b25996d765b72f708bca3", null ],
    [ "radius", "interface_a_map_geo_fence_circle_region.html#a95fa5cf0b68e75ff0a206b168537c86b", null ]
];