var searchData=
[
  ['radius',['radius',['../interface_a_map_geo_fence_circle_region.html#a95fa5cf0b68e75ff0a206b168537c86b',1,'AMapGeoFenceCircleRegion::radius()'],['../interface_a_map_location_circle_region.html#a379663cd2741d56dd55e84d82a4227aa',1,'AMapLocationCircleRegion::radius()']]],
  ['regeocodelanguage',['reGeocodeLanguage',['../interface_a_map_location_manager.html#a5626690eae35235ccfa464fc70fdb6a0',1,'AMapLocationManager']]],
  ['regeocodetimeout',['reGeocodeTimeout',['../interface_a_map_location_manager.html#ab63f44215a784ab7ee64cdfdd16fda53',1,'AMapLocationManager']]],
  ['regiontype',['regionType',['../interface_a_map_geo_fence_region.html#afc5cab5a28cd77268e4ad79569ee0ed0',1,'AMapGeoFenceRegion']]]
];
