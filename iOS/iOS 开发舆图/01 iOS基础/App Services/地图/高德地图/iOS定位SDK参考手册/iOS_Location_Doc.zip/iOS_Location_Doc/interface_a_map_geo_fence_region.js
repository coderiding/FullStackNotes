var interface_a_map_geo_fence_region =
[
    [ "currentLocation", "interface_a_map_geo_fence_region.html#acfd3a908b8164fa784af57bbd1fb3e18", null ],
    [ "customID", "interface_a_map_geo_fence_region.html#a774558f86b8ededef714fc11d091075a", null ],
    [ "fenceStatus", "interface_a_map_geo_fence_region.html#aef46fcada6cfc92e55f74e4a774ad106", null ],
    [ "identifier", "interface_a_map_geo_fence_region.html#a083c979efec477b2df7a5c50219cc0e5", null ],
    [ "regionType", "interface_a_map_geo_fence_region.html#afc5cab5a28cd77268e4ad79569ee0ed0", null ]
];