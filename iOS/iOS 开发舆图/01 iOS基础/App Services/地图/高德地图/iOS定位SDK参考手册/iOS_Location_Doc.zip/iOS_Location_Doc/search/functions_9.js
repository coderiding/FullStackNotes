var searchData=
[
  ['pausedgeofenceregionswithcustomid_3a',['pausedGeoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#a95d311d7252db888a23d3f71d5f4ada7',1,'AMapGeoFenceManager']]],
  ['pausegeofenceregionswithcustomid_3a',['pauseGeoFenceRegionsWithCustomID:',['../interface_a_map_geo_fence_manager.html#ac75fd23c771dc6523b8f1641313ad846',1,'AMapGeoFenceManager']]],
  ['pausethegeofenceregion_3a',['pauseTheGeoFenceRegion:',['../interface_a_map_geo_fence_manager.html#a68683ddbc11a55fe9226f332093fca7b',1,'AMapGeoFenceManager']]]
];
