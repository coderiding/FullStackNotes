var interface_a_map_location_p_o_i_item =
[
    [ "address", "interface_a_map_location_p_o_i_item.html#afb5362a56878a37ac0e1b5f49b7f90ae", null ],
    [ "city", "interface_a_map_location_p_o_i_item.html#a4df93c2677fa0e2cc3d11336195f2766", null ],
    [ "district", "interface_a_map_location_p_o_i_item.html#a55606dd6ac996301bb214126181725b7", null ],
    [ "location", "interface_a_map_location_p_o_i_item.html#a443b74c70998c773ec886d067206fea3", null ],
    [ "name", "interface_a_map_location_p_o_i_item.html#a58569d005067b0705c5b5dd036b4056b", null ],
    [ "pId", "interface_a_map_location_p_o_i_item.html#ae6f5f9101b7fde14cf992dfdf9ac4c25", null ],
    [ "province", "interface_a_map_location_p_o_i_item.html#acee34c5c77efa9fbffd798e79daf8342", null ],
    [ "tel", "interface_a_map_location_p_o_i_item.html#a582d6e5e4b33f3b75bbd6f1d73fdfe37", null ],
    [ "type", "interface_a_map_location_p_o_i_item.html#a3592cdc16de200c8f8854915adf1b0da", null ],
    [ "typeCode", "interface_a_map_location_p_o_i_item.html#a9378d14e63ef6aaa20bc24ac852e60f5", null ]
];