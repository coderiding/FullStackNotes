地图中心选点Demo
========================

MAMapKit 3D v2.6.1
AMapSearchKit v3.0.0